import 'dart:ui';

import 'package:flutter/material.dart';

class Constants{

static Color darkBlue = Colors.lightBlue[900]!;
static double formPadding = 24;
}